# SecureNet VPN Affiliate Site

A clean, mobile-friendly landing page to promote VPN services and earn affiliate commissions. Built with HTML/CSS and optimized for static hosting.

## 🌐 Features
- Responsive design
- Multiple affiliate call-to-actions
- Optimized for GitHub Pages
- Easy to customize

## 🚀 Deployment
Upload to GitHub and enable GitHub Pages under Settings > Pages.

## 🔗 Customize
Replace links with your affiliate URLs and modify styles or layout in `index.html`.

## 📄 License
MIT — free to use and modify.
